"""Render both unified Fist Duel extra atlases with Pillow.

Usage: python render_fighter_extra.py [output_directory]
The adjacent fighter_master_rig.json holds the shared palette roles, original
head pixel stamps and joint-based drawing commands in local frame coordinates.
"""

import json
import math
import sys
from pathlib import Path

from PIL import Image

RIG = json.loads(Path(__file__).with_name("fighter_master_rig.json").read_text(encoding="utf-8"))
CELL_SIZE = 50


def render_frame(player, row, frame):
    """Draw one frame on the original integer grid with a clear one-pixel border."""
    style = RIG["players"][player]
    image = Image.new("RGBA", (CELL_SIZE, CELL_SIZE), (0, 0, 0, 0))

    def ink(name):
        value = int(name[1:], 16) if name.startswith("#") else style["palette"][name]
        return value >> 16, value >> 8 & 255, value & 255, 255

    def plot(x, y, color):
        if not (0 < x < 49 and 0 < y < 49):
            raise ValueError(f"Drawing outside frame: {(player, row, frame, x, y)}")
        image.putpixel((x, y), color)

    def stroke(points, color, width=1):
        for (x, y), (end_x, end_y) in zip(points, points[1:]):
            dx = abs(end_x - x)
            dy = -abs(end_y - y)
            step_x = 1 if x < end_x else -1
            step_y = 1 if y < end_y else -1
            error = dx + dy
            while True:
                for v in range(width):
                    for u in range(width):
                        plot(x + u - width // 2, y + v - width // 2, color)
                if (x, y) == (end_x, end_y):
                    break
                doubled_error = 2 * error
                if doubled_error >= dy:
                    error += dy
                    x += step_x
                if doubled_error <= dx:
                    error += dx
                    y += step_y

    def polygon(points, color, outline):
        xs, ys = zip(*points)
        edges = list(zip(points, points[-1:] + points[:-1]))
        for y in range(min(ys), max(ys) + 1):
            for x in range(min(xs), max(xs) + 1):
                inside = False
                for (u, v), (s, t) in edges:
                    if (v > y) != (t > y) and x < (s - u) * (y - v) / (t - v) + u:
                        inside = not inside
                if inside:
                    plot(x, y, color)
        stroke(points + points[:1], outline or color)

    for action, *args in style["commands"][row][frame]:
        if action == "polygon":
            points, fill, outline = args
            polygon(points, ink(fill), ink(outline) if outline else None)
        elif action == "line":
            points, color, width = args
            stroke(points, ink(color), width)
        elif action == "point":
            x, y, color = args
            plot(x, y, ink(color))
        elif action == "head":
            x, y = args
            for dx, dy, value in style["headPixels"]:
                plot(x + dx, y + dy, (value >> 16, value >> 8 & 255, value & 255, 255))
        elif action == "turn":
            degrees, cx, cy = args
            angle = math.radians(degrees)
            cosine, sine = math.cos(angle), math.sin(angle)
            original = image.copy()
            image.paste((0, 0, 0, 0), (0, 0, 50, 50))
            for y in range(1, 49):
                for x in range(1, 49):
                    sample_x = math.floor(cx + (x - cx) * cosine - (y - cy) * sine + 0.5)
                    sample_y = math.floor(cy + (x - cx) * sine + (y - cy) * cosine + 0.5)
                    if 0 <= sample_x < 50 and 0 <= sample_y < 50:
                        plot(x, y, original.getpixel((sample_x, sample_y)))
        else:
            raise ValueError(f"Unknown draw command {action}")
    return image


def main(output_dir):
    output_dir.mkdir(parents=True, exist_ok=True)
    for player, model in RIG["players"].items():
        atlas = Image.new("RGBA", (500, 600), (0, 0, 0, 0))
        for row, frames in enumerate(model["commands"]):
            for frame in range(len(frames)):
                atlas.paste(render_frame(player, row, frame), (50 * frame, 50 * row))
        atlas.save(output_dir / f"fighter_{player}_extra.png", optimize=True)


if __name__ == "__main__":
    main(Path(sys.argv[1]) if len(sys.argv) > 1 else Path.cwd())
